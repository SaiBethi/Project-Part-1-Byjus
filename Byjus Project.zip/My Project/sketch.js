function preload()
{

Boss = loadImage("BossImg.jpg");
Background = loadImage("Fighting.jpg");
Marcus = loadImage("Marcus.png");
Mark = loadImage("Mark.png");
Mason = loadImage("Mason.png");
Medkit = loadImage("Medkit.png");
Michael = loadImage("Michael.png");
NonPlayer= loadImage("NPC.png");
Shield = loadImage("Shield.png");

}

function setup() 
{

createCanvas(WindowWidth,WindowHeight);


}